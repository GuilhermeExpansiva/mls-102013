/// <mls shortName="designSystem" project="102013" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
